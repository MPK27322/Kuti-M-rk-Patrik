import { TestBed } from '@angular/core/testing';

import { ApikService } from './apik.service';

describe('ApikService', () => {
  let service: ApikService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApikService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
