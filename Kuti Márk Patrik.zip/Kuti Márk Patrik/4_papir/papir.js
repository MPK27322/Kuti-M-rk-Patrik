function papir() {
const magassag = document.getElementById("magassag");
const szelesseg = document.getElementById("szelesseg");
const papirtipus = document.getElementById("papirtipus");
const terulet = document.getElementById("terulet");
const koltseg = document.getElementById("koltseg")

const magassagSzam = parseFloat(magassag.value);
const szelessegSzam = parseFloat(szelesseg.value);
const papirtipusSzam = parseFloat(papirtipus.value);


const teruletSzam = ((szelessegSzam * magassagSzam)/10000).toFixed(0);
const koltsegSzam = (teruletSzam * papirtipusSzam);

document.getElementById("terulet").innerText = teruletSzam


};